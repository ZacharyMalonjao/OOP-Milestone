/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.javamaster.oop;

/**
 *
 * @author zach malonjao
 */


//The purpose of this abstract class is to hide the lengthy calculation for 
//WithHolding Tax and Total Deduction


public abstract class AbstractDeductionCalculator {
    protected double taxableIncome;
    protected Employee emp;
    protected String info;
    protected long withHoldingTax;
    
    protected double basicSalary = emp.getBasicSalary();
    protected double pagibigDeduct;
    protected double philHealthDeduct;
    protected double sssDeduct;
    protected double totalDeduction;
    
   
    
    
    //WITHHOLDING TAX
    protected long calculateWithHoldingTax(double taxableIncome){
     if (taxableIncome < 20832) {
        info = "No withholding tax";
        withHoldingTax = 0;
    } else if (taxableIncome >= 20833 && taxableIncome <= 33333) {
        withHoldingTax = (long) (taxableIncome * 0.2);
        info = String.format("20%% in excess of 20,833: %.2f", taxableIncome - 20833);
    } else if (taxableIncome >= 33333 && taxableIncome <= 66667) {
        withHoldingTax = (long) (taxableIncome * 0.25 - 2500);
        info = String.format("2,500 plus 25%% in excess of 33,333: %.2f", taxableIncome - 33333);
    } else if (taxableIncome >= 66667 && taxableIncome <= 166667) {
        withHoldingTax = (long) (taxableIncome * 0.3 - 10833);
        info = String.format("10,833 plus 30%% in excess of 66,667: %.2f", taxableIncome - 66667);
    } else if (taxableIncome >= 166667 && taxableIncome <= 666667) {
        withHoldingTax = (long) (taxableIncome * 0.32 - 40833.33);
        info = String.format("40,833.33 plus 32%% in excess over 166,667: %.2f", taxableIncome - 166667);
    } else if (taxableIncome > 666667) {
        withHoldingTax = (long) (taxableIncome * 0.35 - 200833.33);
        info = String.format("200,833.33 plus 35%% in excess of 666,667: %.2f", taxableIncome - 666667);
    } else {
        System.out.println("Error");
        info = "";
    }
    
     return withHoldingTax;
    }
    
    
    
    protected String getInfo(){
        return info;
    }
    //TOTAL DEDUCTION
    protected double calculateTotalDeduction(){
        pagibigDeduct= 100;
        philHealthDeduct= basicSalary*0.03;
         if (basicSalary < 3250) {
          sssDeduct = 135.00;
      } else if (basicSalary >= 3250 && basicSalary <= 3750) {
          sssDeduct = 157.00;
      } else if (basicSalary >= 3750 && basicSalary <= 4250) {
          sssDeduct = 180.00;
      } else if (basicSalary >= 4250 && basicSalary <= 4750) {
          sssDeduct = 202.50;
      } else if (basicSalary >= 4750 && basicSalary <= 5250) {
          sssDeduct = 225.00;
      } else if (basicSalary >= 5250 && basicSalary <= 5750) {
          sssDeduct = 247.50;
      } else if (basicSalary >= 5750 && basicSalary <= 6250) {
          sssDeduct = 270.00;
      } else if (basicSalary >= 6250 && basicSalary <= 6750) {
          sssDeduct = 292.50;
      } else if (basicSalary >= 6750 && basicSalary <= 7250) {
          sssDeduct = 315.00;
      } else if (basicSalary >= 7250 && basicSalary <= 7750) {
          sssDeduct = 337.50;
      } else if (basicSalary >= 7750 && basicSalary <= 8250) {
          sssDeduct = 360.00;
      } else if (basicSalary >= 8250 && basicSalary <= 8750) {
          sssDeduct = 382.50;
      } else if (basicSalary >= 8750 && basicSalary <= 9250) {
          sssDeduct = 405.00;
      } else if (basicSalary >= 9250 && basicSalary <= 9750) {
          sssDeduct = 427.50;
      } else if (basicSalary >= 9750 && basicSalary <= 10250) {
          sssDeduct = 450.00;
      } else if (basicSalary >= 10250 && basicSalary <= 10750) {
          sssDeduct = 472.50;
      } else if (basicSalary >= 10750 && basicSalary <= 11250) {
          sssDeduct = 495.00;
      } else if (basicSalary >= 11250 && basicSalary <= 11750) {
          sssDeduct = 517.50;
      } else if (basicSalary >= 11750 && basicSalary <= 12250) {
          sssDeduct = 540.00;
      } else if (basicSalary >= 12250 && basicSalary <= 12750) {
          sssDeduct = 562.50;
      } else if (basicSalary >= 12750 && basicSalary <= 13250) {
          sssDeduct = 585.00;
      } else if (basicSalary >= 13250 && basicSalary <= 13750) {
          sssDeduct = 607.50;
      } else if (basicSalary >= 13750 && basicSalary <= 14250) {
          sssDeduct = 630.00;
      } else if (basicSalary >= 14250 && basicSalary <= 14750) {
          sssDeduct = 652.50;
      } else if (basicSalary >= 14750 && basicSalary <= 15250) {
          sssDeduct = 675.00;
      } else if (basicSalary >= 15250 && basicSalary <= 15750) {
          sssDeduct = 697.50;
      } else if (basicSalary >= 15750 && basicSalary <= 16250) {
          sssDeduct = 720.00;
      } else if (basicSalary >= 16250 && basicSalary <= 16750) {
          sssDeduct = 742.50;
      } else if (basicSalary >= 16750 && basicSalary <= 17250) {
          sssDeduct = 765.00;
      } else if (basicSalary >= 17250 && basicSalary <= 17750) {
          sssDeduct = 787.50;
      } else if (basicSalary >= 17750 && basicSalary <= 18250) {
          sssDeduct = 810.00;
      } else if (basicSalary >= 18250 && basicSalary <= 18750) {
          sssDeduct = 832.50;
      } else if (basicSalary >= 18750 && basicSalary <= 19250) {
          sssDeduct = 855.00;
      } else if (basicSalary >= 19250 && basicSalary <= 19750) {
          sssDeduct = 877.50;
      } else if (basicSalary >= 19750 && basicSalary <= 20250) {
          sssDeduct = 900.00;
      } else if (basicSalary >= 20250 && basicSalary <= 20750) {
          sssDeduct = 922.50;
      } else if (basicSalary >= 20750 && basicSalary <= 21750) {
          sssDeduct = 967.50;
      } else if (basicSalary >= 21750 && basicSalary <= 22250) {
          sssDeduct = 990.00;
      } else if (basicSalary >= 22250 && basicSalary <= 22750) {
          sssDeduct = 1012.50;
      } else if (basicSalary >= 22750 && basicSalary <= 23250) {
          sssDeduct = 1035.00;
      } else if (basicSalary >= 23250 && basicSalary <= 23750) {
          sssDeduct = 1057.50;
      } else if (basicSalary >= 23750 && basicSalary <= 24250) {
          sssDeduct = 1080.00;
      } else if (basicSalary >= 24250 && basicSalary <= 24750) {
          sssDeduct = 1102.50;
      } else if (basicSalary > 24750){ 
          sssDeduct = 1125.50;
      } else {
          System.out.println("Error");
      }
      totalDeduction = sssDeduct+philHealthDeduct+pagibigDeduct;
      return totalDeduction;
       
    }
    
    
    
  
    
    public double getAllowances (Employee emp){
        double allAllowances = emp.getClothingAllowance()+emp.getRiceSubsidy()+emp.getPhoneAllowance();
        return allAllowances;
    }
    
   
    
    
    
    
   
    public double getMonthlyValue(String month){
        double monthlyValue;
            switch(month){
                 case "January": 
                     monthlyValue = 21;
                     break;
                 case "February": 
                     monthlyValue = 20;
                     break;
                 case "March": 
                     monthlyValue = 23;
                     break;
                 case "April": 
                     monthlyValue = 22;
                     break;
                 case "May": 
                     monthlyValue = 22;
                     break;
                 case "June": 
                     monthlyValue = 21;
                     break;
                 case "July": 
                     monthlyValue = 22;
                     break;
                 case "August": 
                     monthlyValue = 23;
                     break;
                 case "September": 
                     monthlyValue = 22;
                     break;
                 case "October": 
                     monthlyValue = 23;
                     break;
                 case "November": 
                     monthlyValue = 22;
                     break;
                 case "December": 
                     monthlyValue = 21;
                     break;
                  default:
                    monthlyValue = 0; // set a default value if no month is selected
                    break;

            }return monthlyValue;
    }
    

    
   
    
}
