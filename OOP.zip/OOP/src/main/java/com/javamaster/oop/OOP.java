/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.javamaster.oop;

/**
 *
 * @author zach malonjao
 */
public class OOP {

    public static void main(String[] args) {
        Login login = new Login();
        login.setVisible(true);
     
        
        
      
        
    }
}
