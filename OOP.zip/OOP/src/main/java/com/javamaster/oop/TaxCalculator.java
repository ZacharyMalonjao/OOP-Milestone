/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.javamaster.oop;

/**
 *
 * @author zach malonjao
 */
public class TaxCalculator extends AbstractTaxCalculator {
    
    private double monthlyValue;
    private String month;
    
    TaxCalculator(Employee emp, String month){
        this.emp=emp;
        this.month=month;
        
    }
    double dailyRate;
   
    double monthlyBasicSalary;
    double allAllowances;
    double grossPay;
    double netPay;
    
    
    public void calculatePayroll(){
        dailyRate = emp.getHourlyRate()*8;  
        monthlyValue = getMonthlyValue(month);
            monthlyBasicSalary = dailyRate * monthlyValue;
            allAllowances = getAllowances(emp);
        grossPay = basicSalary+allAllowances;
        
        totalDeduction = calculateTotalDeduction();
            taxableIncome = basicSalary-totalDeduction; 
            withHoldingTax = calculateWithHoldingTax(taxableIncome);
        
            
            
        netPay = grossPay -(withHoldingTax+totalDeduction );
        
    }
    
    //STUFF TO OUTPUT
    
    
  
    //EARNINGS
    
        public double getGrossPay(){
            return grossPay;
        }
        public double getMonthlyRate(){
            return monthlyBasicSalary;
        }

        public double getDailyRate(){
            return dailyRate;
        }
    //Deductions    
        public double getSssDeduct(){
            return sssDeduct;
        }

        public double getPhilHealthDeduct(){
            return philHealthDeduct;
        }

        public double getPagibigDeduct(){
            return pagibigDeduct;
        }

        public double getWithHoldingTax(){
            return withHoldingTax;
        }
    //Summary
        
        public double getTotalBenefits(){
            return allAllowances;
        }
        
        public double getTotalDeductions(){
            return totalDeduction + withHoldingTax;
        }
    
        public double getNetPay(){
             return netPay;
        }
    
    
}
