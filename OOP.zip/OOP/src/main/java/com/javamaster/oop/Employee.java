/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.javamaster.oop;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
/**
 *
 * @author zach malonjao
 */
public class Employee extends User implements CSVAccessor {
    private List<String[]> csvArrayList;
//    public Employee(String employeeId, String lastName, String firstName, String birthday, String address,
//                    String phoneNumber, String sssNumber, String philhealthNumber, String tinNumber,
//                    String pagIbigNumber, String status, String position, String immediateSupervisor,
//                    double basicSalary, double riceSubsidy, double phoneAllowance, double clothingAllowance,
//                    double grossSemiMonthlyRate, double hourlyRate) {
//        super(employeeId, lastName, firstName, birthday, address, phoneNumber, sssNumber, philhealthNumber,
//              tinNumber, pagIbigNumber, status, position, immediateSupervisor, basicSalary, riceSubsidy,
//              phoneAllowance, clothingAllowance, grossSemiMonthlyRate, hourlyRate);
//    }

 //------------------------------------------------------------------------   
 //ACCESS METHODS 
  //1. GO TO FILE LEAVE
    void accessFileLeave(Employee emp){
        
       FileLeave fl = new FileLeave(emp);
       fl.setVisible(true); 
       
    }
  //2. GO TO SALARY CALC FOR EMPLOYEES 
    void accessEmpSalaryCalculation(Employee emp){
        EmpSalaryCalculation esc = new EmpSalaryCalculation(emp);
        esc.setVisible(true);
    }
    
//------------------------------------------------------------------------    
//CSV TOOLS
    //3. Para magbasa ng csv, use this method.
    @Override
    public List<String[]> loadCSV(String csvFile){
       csvArrayList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] columns = line.split(",");
                csvArrayList.add(columns);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return csvArrayList;
    }
    
    //4. Para magupdate, use this method
    @Override
    public void updateCSV(List<String[]> csvArrayList, String file){
         try{
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            for(String[] updatedcsv:csvArrayList){
                writer.write(String.join(",",updatedcsv));
                writer.newLine();
              }
                writer.close();
        }catch(IOException e){
           e.printStackTrace();}
    }
    //5. Para magsearch, use this method
     @Override
    public String[] searchUserData(List<String[]> csvArrayList, String index){
        for (String[] row : csvArrayList) {
            if (row[0].equals(index)) {
                return row;
            }
        }
        return null; // Returns null if the employee doesn't exist


    }
//------------------------------------------------------------------------
//STUFF THE USER DOES  
  public void fileLeave(String[] leaveData, List<String[]> csvArrayList, String file){
      csvArrayList.add(leaveData);
      updateCSV(csvArrayList,file);
  
    }
  
 
    
}
    
   

    
    

