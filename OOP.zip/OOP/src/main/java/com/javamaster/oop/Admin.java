/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.javamaster.oop;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*
*
 *
 * @author zach malonjao
 */
public class Admin extends User{
//    public Admin(String employeeId, String lastName, String firstName, String birthday, String address,
//                    String phoneNumber, String sssNumber, String philhealthNumber, String tinNumber,
//                    String pagIbigNumber, String status, String position, String immediateSupervisor,
//                    double basicSalary, double riceSubsidy, double phoneAllowance, double clothingAllowance,
//                    double grossSemiMonthlyRate, double hourlyRate) {
//        super(employeeId, lastName, firstName, birthday, address, phoneNumber, sssNumber, philhealthNumber,
//              tinNumber, pagIbigNumber, status, position, immediateSupervisor, basicSalary, riceSubsidy,
//              phoneAllowance, clothingAllowance, grossSemiMonthlyRate, hourlyRate);
//    }
    private List<String[]> csvArrayList;
    
    CSVAccessor csva = new CSVAccessor();
//-----------------------------------------------------------------
//ACCESS ROLES
    
    void accessDatabase(){
        Database db = new Database();
        db.setVisible(true);
    }
    

    @Override
    public void accessLeave(User user){
        //beware FL has no parameters
        FileManagement fm = new FileManagement();
        fm.setVisible(true);
    }
    
   @Override
    public void accessDashboard(User admin){
        AdminDashboard adb = new AdminDashboard((Admin)admin);
           adb.setVisible(true);
    }
    
    @Override
    public void accessSalaryCalculation(User user) {
        
        AdminSalaryCalculation asc = new AdminSalaryCalculation((Admin)user);
            asc.setVisible(true);
       
    }
    
//-----------------------------------------------------------------
//CSV Tools
    //Para magbasa ng csv, use this method.
   
    public List<String[]> loadCSV(String csvFile){
       return csva.loadCSV(csvFile);
    }
    
    //Para magupdate, use this method

    public void updateCSV(List<String[]> csvArrayList, String file){
        csva.updateCSV(csvArrayList, file);
    }
    
    //Para magsearch, use this method

    public String[] searchUserData(List<String[]> csvArrayList, String index){
        return csva.searchUserData(csvArrayList, index);
    }
    
    
    
    
    
   
}
