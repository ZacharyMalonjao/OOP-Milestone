/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.javamaster.oop;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author zach malonjao
 */
public abstract class AbstractLoginValidator {
    
     protected List<String[]> loadCSV(String csvFile){
       List<String[]> csvArrayList = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] columns = line.split(",");
                csvArrayList.add(columns);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        return csvArrayList;
    }
     
     protected String[] searchUserData(List<String[]> csvArrayList, String index){
        for (String[] row : csvArrayList) {
            if (row[0].equals(index)) {
                return row;
            }
        }
        return null;
        
    }
     
    protected void setUserData(Admin admin, UnidentifiedUser unidentifiedUser){
        String index = unidentifiedUser.getEmployeeID();
        List<String[]> csvArrayList = loadCSV("MotorPH.csv");
        String[] userData = searchUserData(csvArrayList, index);
             if (userData == null) {
                throw new IllegalArgumentException("User  data not found for index: " + index);
            }else{
                admin.setEmployeeId(userData[0]);
                admin.setLastName(userData[1]);
                admin.setFirstName(userData[2]);
                admin.setBirthday(userData[3]);
                admin.setAddress(userData[4]);
                admin.setPhoneNumber(userData[5]);
                admin.setSssNumber(userData[6]);
                admin.setPhilhealthNumber(userData[7]);
                admin.setTinNumber(userData[8]);
                admin.setPagIbigNumber(userData[9]);
                admin.setStatus(userData[10]);
                admin.setPosition(userData[11]);
                admin.setImmediateSupervisor(userData[12]);
                admin.setBasicSalary(Double.parseDouble(userData[13]));
                admin.setRiceSubsidy(Double.parseDouble(userData[14]));
                admin.setPhoneAllowance(Double.parseDouble(userData[15]));
                admin.setClothingAllowance(Double.parseDouble(userData[16]));
                admin.setGrossSemiMonthlyRate(Double.parseDouble(userData[17]));
                admin.setHourlyRate(Double.parseDouble(userData[18]));
             }
    }  
    protected void setUserData(Employee emp, UnidentifiedUser unidentifiedUser){
        String index = unidentifiedUser.getEmployeeID();
        List<String[]> csvArrayList = loadCSV("MotorPH.csv");
        String[] userData = searchUserData(csvArrayList, index);
        
            if (userData == null) {
                throw new IllegalArgumentException("User  data not found for index: " + index);
            }else{
                emp.setEmployeeId(userData[0]);
                emp.setLastName(userData[1]);
                emp.setFirstName(userData[2]);
                emp.setBirthday(userData[3]);
                emp.setAddress(userData[4]);
                emp.setPhoneNumber(userData[5]);
                emp.setSssNumber(userData[6]);
                emp.setPhilhealthNumber(userData[7]);
                emp.setTinNumber(userData[8]);
                emp.setPagIbigNumber(userData[9]);
                emp.setStatus(userData[10]);
                emp.setPosition(userData[11]);
                emp.setImmediateSupervisor(userData[12]);
                emp.setBasicSalary(Double.parseDouble(userData[13]));
                emp.setRiceSubsidy(Double.parseDouble(userData[14]));
                emp.setPhoneAllowance(Double.parseDouble(userData[15]));
                emp.setClothingAllowance(Double.parseDouble(userData[16]));
                emp.setGrossSemiMonthlyRate(Double.parseDouble(userData[17]));
           }    emp.setHourlyRate(Double.parseDouble(userData[18]));
            
    } 
    
    
}
